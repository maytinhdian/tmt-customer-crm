<?php
// bootstrap (file chính)
declare(strict_types=1);

namespace TMT\CRM\Core\Accounts;

use TMT\CRM\Core\Accounts\Infrastructure\Providers\AccountsServiceProvider;
use TMT\CRM\Core\Accounts\Presentation\Admin\Ajax\UserAjaxController;

final class AccountsModule
{
    public static function bootstrap(): void // dùng từ bootstrap (file chính)
    {
        AccountsServiceProvider::register();

        // Đăng ký AJAX picker dùng chung
        add_action('init', [UserAjaxController::class, 'bootstrap']);
    }
}
