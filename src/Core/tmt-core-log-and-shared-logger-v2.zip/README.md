# TMT CRM — Shared Logger + Core/Log Module

- **Shared Logger**: dùng ở mọi nơi (không phụ thuộc module). Namespace: `TMT\CRM\Shared\Logging`.
- **Core/Log**: module nhỏ cung cấp UI xem log & Installer DB. Namespace: `TMT\CRM\Core\Log`.

## Cài đặt nhanh
1. Đặt thư mục `src/` vào plugin `tmt-customer-crm` của bạn.
2. Trong plugin chính `tmt-customer-crm.php`, gọi:
   ```php
   \TMT\CRM\Core\Log\LogModule::bootstrap();
   ```

## Sử dụng
```php
use TMT\CRM\Shared\Container\Container;
use TMT\CRM\Shared\Logging\LoggerInterface;

$logger = Container::get(LoggerInterface::class);
$logger->info('Company created', ['company_id' => 123]);
```
