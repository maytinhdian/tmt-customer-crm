# TMT CRM – Core/Settings

- Module Core/Settings tạo trang cấu hình CRM tại **Cài đặt → TMT CRM → Cài đặt**.
- Lưu dữ liệu vào `wp_options` với key: `tmt_crm_settings`.
- Cho phép **module khác** tự đăng ký section/field qua filter `tmt_crm_settings_sections`.

## Cài đặt
- Copy các file vào plugin theo đúng PSR-4 (`TMT\CRM\` → `src/`).
- Đảm bảo bạn đã có `Shared/View.php` với `View::render_admin_module()`.
- Trong bootstrap (file chính):
  ```php
  use TMT\CRM\Core\Settings\SettingsPage;
  use TMT\CRM\Modules\Company\CompanyModule;
  add_action('plugins_loaded', function () {
      // Core/Settings (file chính)
      SettingsPage::register();
      // Company (file chính)
      CompanyModule::register();
  }, 1);
  ```

## Ghi nhớ
- Class PascalCase, hàm snake_case.
- DTO đuôi `DTO` (quy ước chung toàn dự án).
- Sau khi thêm file, chạy: `composer dump-autoload -o`.
