<?php
declare(strict_types=1);

namespace TMT\CRM\Modules\Company\Core;

use TMT\CRM\Core\Settings\SettingsSectionInterface;
use TMT\CRM\Core\Settings\Settings;

final class CompanySettingsSection implements SettingsSectionInterface
{
    public function section_id(): string
    {
        return 'company_settings';
    }

    public function section_title(): string
    {
        return __('Công ty', 'tmt-crm');
    }

    public function get_defaults(): array
    {
        return [
            'company_auto_numbering' => true,
            'company_code_prefix'    => 'CMP',
            'company_numbering_next' => 1001,
            'company_default_owner'  => 0,
        ];
    }

    public function register_fields(string $page_slug, string $option_key): void
    {
        // 1) Bật/tắt tự động đánh số
        add_settings_field(
            'company_auto_numbering',
            __('Tự động đánh số mã công ty', 'tmt-crm'),
            function () use ($option_key) {
                $checked = Settings::get('company_auto_numbering', true) ? 'checked' : '';
                echo '<label><input type="checkbox" name="' . esc_attr($option_key) . '[company_auto_numbering]" value="1" ' . $checked . ' />';
                echo ' ' . esc_html__('Bật', 'tmt-crm') . '</label>';
            },
            $page_slug,
            $this->section_id()
        );

        // 2) Tiền tố mã
        add_settings_field(
            'company_code_prefix',
            __('Tiền tố mã công ty', 'tmt-crm'),
            function () use ($option_key) {
                $val = (string) Settings::get('company_code_prefix', 'CMP');
                echo '<input type="text" name="' . esc_attr($option_key) . '[company_code_prefix]" value="' . esc_attr($val) . '" />';
                echo '<p class="description">' . esc_html__('Ví dụ: CMP → CMP-1001.', 'tmt-crm') . '</p>';
            },
            $page_slug,
            $this->section_id()
        );

        // 3) Số tiếp theo
        add_settings_field(
            'company_numbering_next',
            __('Số tiếp theo', 'tmt-crm'),
            function () use ($option_key) {
                $val = (int) Settings::get('company_numbering_next', 1001);
                echo '<input type="number" min="1" step="1" name="' . esc_attr($option_key) . '[company_numbering_next]" value="' . esc_attr($val) . '" />';
                echo '<p class="description">' . esc_html__('Khi tạo công ty mới nếu auto-numbering bật.', 'tmt-crm') . '</p>';
            },
            $page_slug,
            $this->section_id()
        );

        // 4) Chủ sở hữu mặc định (user)
        add_settings_field(
            'company_default_owner',
            __('Nhân sự phụ trách mặc định', 'tmt-crm'),
            function () use ($option_key) {
                $current = (int) Settings::get('company_default_owner', 0);
                $users = get_users(['fields' => ['ID', 'display_name']]);
                echo '<select name="' . esc_attr($option_key) . '[company_default_owner]">';
                echo '<option value="0">' . esc_html__('— Không đặt —', 'tmt-crm') . '</option>';
                foreach ($users as $u) {
                    $sel = selected($current, (int) $u->ID, false);
                    echo '<option value="' . (int) $u->ID . '" ' . $sel . '>' . esc_html($u->display_name) . '</option>';
                }
                echo '</select>';
                echo '<p class="description">' . esc_html__('Khi tạo công ty mới mà không chỉ định owner.', 'tmt-crm') . '</p>';
            },
            $page_slug,
            $this->section_id()
        );
    }

    public function sanitize(array $input, array $current_all): array
    {
        $out = [];

        // Checkbox: auto_numbering
        $out['company_auto_numbering'] = !empty($input['company_auto_numbering']);

        // Prefix: chuỗi A–Z, 0–9, dấu - _
        $prefix = isset($input['company_code_prefix']) ? (string) $input['company_code_prefix'] : 'CMP';
        $prefix = strtoupper(preg_replace('/[^A-Z0-9\-_]/i', '', $prefix));
        $out['company_code_prefix'] = $prefix !== '' ? $prefix : 'CMP';

        // Next number: số nguyên >=1
        $next = isset($input['company_numbering_next']) ? (int) $input['company_numbering_next'] : 1001;
        $out['company_numbering_next'] = max(1, $next);

        // Default owner: user ID (>=0)
        $owner = isset($input['company_default_owner']) ? (int) $input['company_default_owner'] : 0;
        $out['company_default_owner'] = max(0, $owner);

        return $out;
    }
}
