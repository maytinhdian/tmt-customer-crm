<?php
declare(strict_types=1);

namespace TMT\CRM\Modules\Company;

use TMT\CRM\Modules\Company\Core\CompanySettingsSection;

final class CompanyModule
{
    /** Gọi 1 lần ở bootstrap (file chính) */
    public static function register(): void
    {
        // Đăng ký section Settings của module Company
        add_filter('tmt_crm_settings_sections', function (array $sections) {
            $sections[] = new CompanySettingsSection();
            return $sections;
        });
    }
}
